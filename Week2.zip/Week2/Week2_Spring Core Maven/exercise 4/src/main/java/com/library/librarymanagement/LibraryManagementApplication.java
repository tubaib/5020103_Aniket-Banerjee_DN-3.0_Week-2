package com.library.librarymanagement;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementApplication {

    public static void main(String[] args) {
        System.out.println("Welcome to Library Management Application!");
    }

}
